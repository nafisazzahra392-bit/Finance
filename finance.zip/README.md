# Suhita Finance

Aplikasi keuangan pribadi offline (HTML + CSS + JavaScript murni).
Tidak butuh login, server, atau koneksi internet setelah file tersedia di HP.

## Struktur Folder
suhita-finance/
├── index.html
├── style.css
├── app.js
└── README.md

## Cara Menjalankan di HP Android (paling mudah)

1. Salin keempat file ke folder yang sama di HP
   (misal `Download/suhita-finance/`).
2. Buka aplikasi **Files** → cari `index.html`.
3. Ketuk file tersebut → pilih **Chrome** (atau browser lain).
4. Aplikasi langsung berjalan. Tambahkan ke layar utama:
   menu Chrome (⋮) → **Tambahkan ke Layar utama**.

### Jika data tidak tersimpan (file:// )
Beberapa browser membatasi `localStorage` untuk file yang dibuka langsung
dari penyimpanan. Jika setelah ditutup data hilang:

**Opsi A (disarankan)** — letakkan di hosting gratis statis
(GitHub Pages, Netlify Drop, Cloudflare Pages). Cukup unggah folder ini,
lalu buka tautannya di HP. Setelah itu data tersimpan normal.

**Opsi B** — jalankan server lokal di PC, akses dari HP: