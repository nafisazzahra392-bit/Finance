function openTxForm(type, data){
  data = data || {};
  var isEdit = !!data.id;
  var title = type==='income' ? 'Pemasukan' : (type==='expense' ? 'Pengeluaran' : 'Transfer');
  var accounts = state.accounts.filter(function(a){ return !a.archived || a.id===data.accountId || a.id===data.toAccountId; });
  if(!accounts.length){ toast('Tambahkan rekening terlebih dahulu', 'err'); showView('accounts'); return; }
  function accOptions(selected){
    return accounts.map(function(a){
      return '<option value="' + a.id + '"' + (a.id===selected?' selected':'') + '>' + esc(a.name) + (a.archived?' (arsip)':'') + '</option>';
    }).join('');
  }
  var dateVal = data.date || todayISO();
  var form = '';
  if(type==='income'){
    var canSplit = !isEdit && isBudgetReady();
    form = '<div class="field"><label>Nominal</label><input name="amount" type="text" inputmode="numeric" placeholder="0" value="' + (data.amount?data.amount.toLocaleString('id-ID'):'') + '" /></div>' +
      '<div class="field"><label>Sumber pendapatan</label><input name="source" type="text" maxlength="60" placeholder="Contoh: Gaji Koperasi" value="' + esc(data.source||'') + '" /></div>' +
      '<div class="field"><label>Rekening tujuan</label><select name="accountId">' + accOptions(data.accountId) + '</select></div>' +
      '<div class="field"><label>Tanggal</label><input name="date" type="date" value="' + dateVal + '" /></div>' +
      '<div class="field"><label>Catatan (opsional)</label><input name="note" type="text" maxlength="200" placeholder="Keterangan tambahan" value="' + esc(data.note||'') + '" /></div>' +
      (!isEdit ? (canSplit ? '<label class="check"><input type="checkbox" name="doSplit" /> Bagi pemasukan ini ke anggaran kategori</label>' : '<p class="hint">Atur kategori anggaran hingga total 100% untuk mengaktifkan pembagian otomatis.</p>') : '');
  } else if(type==='expense'){
    var catOptions = state.categories.map(function(c){
      return '<option value="' + c.id + '"' + (c.id===data.categoryId?' selected':'') + '>' + esc(c.name) + '</option>';
    }).join('');
    form = '<div class="field"><label>Nominal</label><input name="amount" type="text" inputmode="numeric" placeholder="0" value="' + (data.amount?data.amount.toLocaleString('id-ID'):'') + '" /></div>' +
      '<div class="field"><label>Kategori</label><select name="categoryId"><option value=""' + (!data.categoryId?' selected':'') + '>Tanpa kategori</option>' + catOptions + '</select></div>' +
      '<div class="field"><label>Rekening sumber</label><select name="accountId">' + accOptions(data.accountId) + '</select></div>' +
      '<div class="field"><label>Tanggal</label><input name="date" type="date" value="' + dateVal + '" /></div>' +
      '<div class="field"><label>Catatan (opsional)</label><input name="note" type="text" maxlength="200" placeholder="Keterangan tambahan" value="' + esc(data.note||'') + '" /></div>';
  } else {
    function accOptions2(selected, exclude){
      return accounts.filter(function(a){ return a.id !== exclude; }).map(function(a){
        return '<option value="' + a.id + '"' + (a.id===selected?' selected':'') + '>' + esc(a.name) + '</option>';
      }).join('');
    }
    form = '<div class="field"><label>Nominal</label><input name="amount" type="text" inputmode="numeric" placeholder="0" value="' + (data.amount?data.amount.toLocaleString('id-ID'):'') + '" /></div>' +
      '<div class="field"><label>Dari rekening</label><select name="accountId" id="trFrom">' + accOptions2(data.accountId, null) + '</select></div>' +
      '<div class="field"><label>Ke rekening</label><select name="toAccountId" id="trTo">' + accOptions2(data.toAccountId, data.accountId) + '</select></div>' +
      '<div class="field"><label>Tanggal</label><input name="date" type="date" value="' + dateVal + '" /></div>' +
      '<div class="field"><label>Catatan (opsional)</label><input name="note" type="text" maxlength="200" placeholder="Keterangan tambahan" value="' + esc(data.note||'') + '" /></div>';
  }
  openModal('<h3>' + (isEdit?'Edit ':'Catat ') + title + '</h3><form id="txForm">' + form + '<div class="modal-actions"><button type="button" class="btn btn-ghost" data-action="closeModal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div></form>');
  bindAmountInput(document.querySelector('#txForm [name="amount"]'));
  if(type==='transfer'){
    var from = $('trFrom'), to = $('trTo');
    if(from && to){
      var sync = function(){
        var opts = Array.prototype.slice.call(to.options);
        var firstValid = null;
        opts.forEach(function(o){
          var same = o.value === from.value;
          o.disabled = same; o.hidden = same;
          if(!same && !firstValid) firstValid = o.value;
        });
        if(to.value === from.value && firstValid) to.value = firstValid;
      };
      from.addEventListener('change', sync);
      sync();
    }
  }
  $('txForm').addEventListener('submit', function(e){
    e.preventDefault();
    var fd = new FormData(e.target);
    var amount = parseAmountInput(fd.get('amount'));
    if(!(amount > 0)){ toast('Nominal harus lebih dari 0', 'err'); return; }
    var date = isISODate(String(fd.get('date'))) ? String(fd.get('date')) : todayISO();
    var accountId = String(fd.get('accountId')||'');
    if(!accountId){ toast('Pilih rekening', 'err'); return; }
    var base = { id: data.id || uid(), type: type, amount: amount, date: date, accountId: accountId, toAccountId:'', categoryId:'', source:'', note: String(fd.get('note')||'').trim().slice(0,200), createdAt: data.createdAt || new Date().toISOString() };
    if(type==='income'){
      base.source = String(fd.get('source')||'').trim().slice(0,60);
      if(!isEdit && fd.get('doSplit')){ openAllocationSheet(amount, date, base); return; }
    } else if(type==='expense'){
      base.categoryId = String(fd.get('categoryId')||'');
    } else {
      base.toAccountId = String(fd.get('toAccountId')||'');
      if(!base.toAccountId || base.toAccountId === accountId){ toast('Rekening tujuan harus berbeda', 'err'); return; }
    }
    upsertTx(base); save(); closeModal(); render();
    toast(isEdit ? 'Transaksi diperbarui' : 'Transaksi berhasil disimpan');
  });
}

function openTxDetail(id){
  var t = state.transactions.filter(function(x){ return x.id === id; })[0];
  if(!t) return;
  var rows = '';
  function line(label, value){
    return '<div class="row-between" style="padding:8px 0;border-bottom:1px solid var(--line);font-size:13.5px"><span style="color:var(--muted)">' + esc(label) + '</span><strong style="text-align:right">' + value + '</strong></div>';
  }
  if(t.type==='income'){
    rows += line('Jenis','Pemasukan') + line('Nominal','<span class="pos">' + rupiah(t.amount) + '</span>') + line('Sumber', esc(t.source||'-')) + line('Rekening tujuan', esc(accountName(t.accountId)));
  } else if(t.type==='expense'){
    rows += line('Jenis','Pengeluaran') + line('Nominal','<span class="neg">' + rupiah(t.amount) + '</span>') + line('Kategori', esc(categoryName(t.categoryId))) + line('Rekening sumber', esc(accountName(t.accountId)));
  } else {
    rows += line('Jenis','Transfer') + line('Nominal', rupiah(t.amount)) + line('Dari', esc(accountName(t.accountId))) + line('Ke', esc(accountName(t.toAccountId)));
  }
  rows += line('Tanggal', fmtDate(t.date));
  if(t.note) rows += line('Catatan', esc(t.note));
  openModal('<h3>Detail Transaksi</h3><p class="modal-sub">' + (t.type==='transfer'?'Transfer tidak dihitung sebagai pemasukan atau pengeluaran.':'Saldo rekening dihitung ulang otomatis.') + '</p>' + rows + '<div class="modal-actions"><button class="btn btn-danger" data-action="deleteTx" data-id="' + t.id + '">Hapus</button><button class="btn btn-primary" data-action="editTx" data-id="' + t.id + '">Edit</button></div>');
}
function deleteTx(id){
  if(!confirm('Hapus transaksi ini? Saldo rekening akan dihitung ulang.')) return;
  state.transactions = state.transactions.filter(function(t){ return t.id !== id; });
  save(); closeModal(); render(); toast('Transaksi dihapus');
}

function monthOptions(){
  var set = {}; set[monthKeyOf(todayISO())] = true;
  state.transactions.forEach(function(t){ var k = monthKeyOf(t.date); if(k) set[k] = true; });
  return Object.keys(set).sort().reverse();
}
function filteredTx(){
  return sortedTxDesc(state.transactions.filter(function(t){
    if(txFilter.month !== 'all' && monthKeyOf(t.date) !== txFilter.month) return false;
    if(txFilter.type !== 'all' && t.type !== txFilter.type) return false;
    if(txFilter.accountId !== 'all'){
      if(t.type === 'transfer'){ if(t.accountId !== txFilter.accountId && t.toAccountId !== txFilter.accountId) return false; }
      else if(t.accountId !== txFilter.accountId) return false;
    }
    if(txFilter.categoryId !== 'all' && t.categoryId !== txFilter.categoryId) return false;
    return true;
  }));
}
function renderTransactions(){
  var months = monthOptions();
  var list = filteredTx();
  var html = '<div class="tx-actions"><button class="btn btn-primary" data-action="newTx" data-type="income">' + ICONS.income + '<span>Pemasukan</span></button><button class="btn btn-ghost" data-action="newTx" data-type="expense">' + ICONS.expense + '<span>Pengeluaran</span></button><button class="btn btn-ghost" data-action="newTx" data-type="transfer">' + ICONS.transfer + '<span>Transfer</span></button></div>';
  html += '<div class="filters"><select id="filterMonth"><option value="all">Semua bulan</option>' + months.map(function(m){ return '<option value="' + m + '"' + (txFilter.month===m?' selected':'') + '>' + fmtMonth(m) + '</option>'; }).join('') + '</select><select id="filterType"><option value="all">Semua jenis</option><option value="income"' + (txFilter.type==='income'?' selected':'') + '>Pemasukan</option><option value="expense"' + (txFilter.type==='expense'?' selected':'') + '>Pengeluaran</option><option value="transfer"' + (txFilter.type==='transfer'?' selected':'') + '>Transfer</option></select><select id="filterAccount"><option value="all">Semua rekening</option>' + state.accounts.map(function(a){ return '<option value="' + a.id + '"' + (txFilter.accountId===a.id?' selected':'') + '>' + esc(a.name) + '</option>'; }).join('') + '</select><select id="filterCategory"><option value="all">Semua kategori</option>' + state.categories.map(function(c){ return '<option value="' + c.id + '"' + (txFilter.categoryId===c.id?' selected':'') + '>' + esc(c.name) + '</option>'; }).join('') + '</select></div>';
  if(!list.length){
    html += '<div class="card empty" style="margin-top:14px"><p class="empty-title">' + (state.transactions.length?'Tidak ada transaksi yang cocok':'Belum ada transaksi') + '</p><p class="empty-text">' + (state.transactions.length?'Coba ubah filter.':'Tekan tombol Pemasukan, Pengeluaran, atau Transfer di atas untuk mulai mencatat.') + '</p></div>';
  } else {
    var lastDate = '';
    html += '<div class="card" style="margin-top:14px">';
    list.forEach(function(t){
      if(t.date !== lastDate){
        if(lastDate) html += '</div><div class="card" style="margin-top:14px">';
        html += '<p class="date-head" style="margin-top:2px">' + fmtDate(t.date) + '</p>';
        lastDate = t.date;
      }
      html += txRow(t);
    });
    html += '</div>';
  }
  $('view-transactions').innerHTML = html;
}

function renderReports(){
  var mk = reportMonth || monthKeyOf(todayISO());
  var months = monthOptions();
  if(months.indexOf(mk) === -1) months = months.concat([mk]).sort().reverse();
  var monthTx = state.transactions.filter(function(t){ return monthKeyOf(t.date) === mk; });
  var income = 0, expense = 0;
  monthTx.forEach(function(t){ if(t.type==='income') income += t.amount; else if(t.type==='expense') expense += t.amount; });
  var net = income - expense;
  var byCat = {};
  monthTx.forEach(function(t){
    if(t.type !== 'expense') return;
    var k = (t.categoryId && categoryById(t.categoryId)) ? t.categoryId : '__none';
    byCat[k] = (byCat[k]||0) + t.amount;
  });
  var catEntries = Object.keys(byCat).map(function(k){ return [k, byCat[k]]; }).sort(function(a,b){ return b[1]-a[1]; });
  var maxVal = catEntries.reduce(function(m,e){ return Math.max(m, e[1]); }, 0) || 1;
  var html = '<div class="card"><div class="field" style="margin:0"><label>Bulan laporan</label><select id="reportMonth">' + months.map(function(m){ return '<option value="' + m + '"' + (m===mk?' selected':'') + '>' + fmtMonth(m) + '</option>'; }).join('') + '</select></div></div>';
  html += '<div class="stat-row"><div class="stat"><span class="stat-label"><i class="dot dot-in"></i>Pemasukan</span><span class="stat-value pos">' + rupiah(income) + '</span></div><div class="stat"><span class="stat-label"><i class="dot dot-out"></i>Pengeluaran</span><span class="stat-value neg">' + rupiah(expense) + '</span></div></div>';
  html += '<div class="card" style="margin-top:12px"><div class="row-between"><span style="font-size:13px;font-weight:600">Selisih bulan ini</span><strong class="' + (net<0?'neg':'pos') + '" style="font-size:16px">' + rupiah(net) + '</strong></div></div>';
  html += '<div class="section"><div class="section-head"><h2>Pengeluaran per Kategori</h2></div>';
  if(!catEntries.length){
    html += emptyState('Belum ada pengeluaran', 'Belum ada pengeluaran tercatat pada bulan ini.', null, null);
  } else {
    html += '<div class="card">' + catEntries.map(function(e){
      var name = e[0]==='__none' ? 'Tanpa kategori' : categoryName(e[0]);
      var w = Math.max(3, Math.round(e[1]/maxVal*100));
      return '<div class="bar-row"><div class="bar-top"><span>' + esc(name) + '</span><strong>' + rupiah(e[1]) + '</strong></div><div class="bar-track"><div class="bar-fill" style="width:' + w + '%"></div></div></div>';
    }).join('') + '</div>';
  }
  html += '</div>';
  html += '<div class="section"><div class="section-head"><h2>Anggaran vs Aktual</h2></div>';
  if(!state.categories.length){
    html += emptyState('Belum ada kategori anggaran', 'Tambahkan kategori pada menu Anggaran untuk melihat perbandingan.', null, null);
  } else {
    html += '<div class="card">';
    state.categories.forEach(function(c){
      var alloc = allocatedForMonth(c.id, mk);
      var spent = monthTx.filter(function(t){ return t.type==='expense' && t.categoryId===c.id; }).reduce(function(s,t){ return s + t.amount; }, 0);
      var sisa = alloc - spent;
      var pct = alloc>0 ? Math.min(100, Math.round(spent/alloc*100)) : (spent>0?100:0);
      html += '<div style="padding:10px 0;border-bottom:1px solid var(--line)"><div class="row-between" style="font-size:13.5px;font-weight:600"><span>' + esc(c.name) + '</span><span class="' + (sisa<0?'neg':'pos') + '">' + rupiah(sisa) + '</span></div><div class="progress"><div style="width:' + pct + '%"></div></div><div class="bud-bottom"><span>Anggaran ' + rupiah(alloc) + '</span><span>Aktual ' + rupiah(spent) + '</span></div></div>';
    });
    html += '</div>';
  }
  html += '</div>';
  html += '<button class="btn btn-ghost btn-block" data-action="gotoTxMonth" data-month="' + mk + '" style="margin-top:16px">Lihat Riwayat Transaksi ' + fmtMonth(mk) + '</button>';
  $('view-reports').innerHTML = html;
}

function openDataSheet(){
  openModal('<h3>Data & Cadangan</h3><p class="modal-sub">Semua data tersimpan di perangkat ini. Menghapus data browser dapat menyebabkan kehilangan data jika belum dicadangkan.</p><div style="display:flex;flex-direction:column;gap:10px"><button class="btn btn-primary" data-action="exportData">Ekspor Cadangan (JSON)</button><button class="btn" data-action="importData">Impor Cadangan (JSON)</button><button class="btn btn-danger" data-action="resetData">Hapus Semua Data</button></div><p class="hint" style="margin-top:16px">Ringkasan: ' + state.accounts.length + ' rekening, ' + state.categories.length + ' kategori, ' + state.transactions.length + ' transaksi, ' + state.allocations.length + ' pembagian.</p><div class="modal-actions"><button class="btn btn-ghost" data-action="closeModal">Tutup</button></div>');
}
function exportData(){
  var payload = { app:'Suhita Finance', version:1, exportedAt: new Date().toISOString(), accounts:state.accounts, categories:state.categories, transactions:state.transactions, allocations:state.allocations };
  try {
    var blob = new Blob([JSON.stringify(payload, null, 2)], { type:'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = 'suhita-cadangan-' + todayISO() + '.json';
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 1500);
    toast('Cadangan berhasil diunduh');
  } catch(e){ toast('Gagal membuat file cadangan', 'err'); }
}
function importData(file){
  var reader = new FileReader();
  reader.onload = function(){
    var parsed;
    try { parsed = JSON.parse(String(reader.result)); }
    catch(e){ toast('File bukan JSON valid', 'err'); return; }
    var res = sanitizeState(parsed, true);
    if(!res.ok){ toast('Impor gagal: ' + res.error, 'err'); return; }
    if(!confirm('Impor akan MENGGANTI seluruh data saat ini. Lanjutkan?')) return;
    state = res.state; save();
    reportMonth = monthKeyOf(todayISO());
    txFilter = { month:'all', type:'all', accountId:'all', categoryId:'all' };
    closeModal(); render(); toast('Data berhasil diimpor');
  };
  reader.onerror = function(){ toast('Gagal membaca file', 'err'); };
  reader.readAsText(file);
}
function resetData(){
  if(!confirm('Hapus SEMUA data? Tindakan ini tidak dapat dibatalkan.')) return;
  if(!confirm('Yakin? Sebaiknya ekspor cadangan terlebih dahulu.')) return;
  state = { version:1, accounts:[], categories:[], transactions:[], allocations:[] };
  save(); closeModal(); render(); toast('Semua data dihapus');
}

document.addEventListener('click', function(e){
  var navLink = e.target.closest('[data-nav-link]');
  if(navLink){ showView(navLink.getAttribute('data-nav-link')); return; }
  var btn = e.target.closest('[data-action]');
  if(!btn) return;
  var action = btn.getAttribute('data-action');
  var id = btn.getAttribute('data-id');
  switch(action){
    case 'closeModal': closeModal(); break;
    case 'openData': openDataSheet(); break;
    case 'exportData': exportData(); break;
    case 'importData': { var f = $('importFile'); if(f) f.click(); break; }
    case 'resetData': resetData(); break;
    case 'addAccount': openAccountForm(null); break;
    case 'editAccount': openAccountForm(accountById(id)); break;
    case 'toggleArchive': toggleArchive(id); break;
    case 'accHistory':
      txFilter = { month:'all', type:'all', accountId:id, categoryId:'all' };
      showView('transactions');
      break;
    case 'addCategory': openCategoryForm(null); break;
    case 'editCategory': openCategoryForm(categoryById(id)); break;
    case 'deleteCategory': deleteCategory(id); break;
    case 'manualAlloc': openManualAlloc(); break;
    case 'confirmAlloc': confirmAllocation(); break;
    case 'skipAlloc': skipAllocation(); break;
    case 'newTx': openTxForm(btn.getAttribute('data-type'), {}); break;
    case 'openTx': openTxDetail(id); break;
    case 'editTx': { var t = state.transactions.filter(function(x){ return x.id === id; })[0]; if(t) openTxForm(t.type, t); break; }
    case 'deleteTx': deleteTx(id); break;
    case 'gotoTransactions': showView('transactions'); break;
    case 'gotoTxMonth':
      txFilter = { month:btn.getAttribute('data-month'), type:'all', accountId:'all', categoryId:'all' };
      showView('transactions');
      break;
  }
});

document.addEventListener('change', function(e){
  var t = e.target; if(!t || !t.id) return;
  if(t.id==='filterMonth'){ txFilter.month = t.value; renderTransactions(); }
  else if(t.id==='filterType'){ txFilter.type = t.value; renderTransactions(); }
  else if(t.id==='filterAccount'){ txFilter.accountId = t.value; renderTransactions(); }
  else if(t.id==='filterCategory'){ txFilter.categoryId = t.value; renderTransactions(); }
  else if(t.id==='reportMonth'){ reportMonth = t.value; renderReports(); }
  else if(t.id==='importFile'){ if(t.files && t.files[0]) importData(t.files[0]); t.value=''; }
});

var navBtns = document.querySelectorAll('.nav-btn');
for(var i=0;i<navBtns.length;i++){
  (function(b){ b.addEventListener('click', function(){ showView(b.getAttribute('data-nav')); }); })(navBtns[i]);
}
document.addEventListener('keydown', function(e){ if(e.key === 'Escape') closeModal(); });

load();
reportMonth = monthKeyOf(todayISO());
render();