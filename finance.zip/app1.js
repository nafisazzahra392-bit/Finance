'use strict';

var STORAGE_KEY = 'suhita_finance_v1';
var MONTH_NAMES = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

var state = { version: 1, accounts: [], categories: [], transactions: [], allocations: [] };
var currentView = 'dashboard';
var txFilter = { month: 'all', type: 'all', accountId: 'all', categoryId: 'all' };
var reportMonth = '';
var allocContext = null;

var ICONS = {
  income: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 4.5v14"/><path d="m6 13 6 6 6-6"/></svg>',
  expense: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19.5v-14"/><path d="m6 11 6-6 6 6"/></svg>',
  transfer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8h13"/><path d="m13 4 4 4-4 4"/><path d="M20 16H7"/><path d="m11 20-4-4 4-4"/></svg>'
};

function $(id){ return document.getElementById(id); }
function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,7); }
function num(v){ var n = Math.round(Number(v)); return isFinite(n) ? n : 0; }
function rupiah(v){
  var n = Math.round(Number(v) || 0);
  var s = Math.abs(n).toLocaleString('id-ID');
  return (n < 0 ? '-Rp' : 'Rp') + s;
}
function esc(v){
  return String(v == null ? '' : v).replace(/[&<>"']/g, function(c){
    return { '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c];
  });
}
function fmtPct(p){ var n = Math.round((Number(p)||0)*100)/100; return String(n).replace('.', ',') + '%'; }
function isISODate(s){ return typeof s === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(s); }
function monthKeyOf(iso){ return isISODate(iso) ? iso.slice(0,7) : ''; }
function pad2(n){ return (n < 10 ? '0' : '') + n; }
function todayISO(){ var d = new Date(); return d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate()); }
function fmtDate(iso){ if(!isISODate(iso)) return '-'; var p = iso.split('-').map(Number); return p[2] + ' ' + MONTH_NAMES[p[1]-1] + ' ' + p[0]; }
function fmtDateShort(iso){ if(!isISODate(iso)) return '-'; var p = iso.split('-').map(Number); return p[2] + ' ' + MONTH_NAMES[p[1]-1].slice(0,3) + ' ' + p[0]; }
function fmtMonth(key){ if(!/^\d{4}-\d{2}$/.test(key || '')) return '-'; var p = key.split('-').map(Number); return MONTH_NAMES[p[1]-1] + ' ' + p[0]; }
function parseAmountInput(v){ return num(String(v == null ? '' : v).replace(/[^\d]/g, '')); }

function bindAmountInput(input){
  if(!input) return;
  input.addEventListener('input', function(e){
    var d = e.target.value.replace(/\D/g, '').slice(0, 15);
    e.target.value = d ? Number(d).toLocaleString('id-ID') : '';
  });
}

var toastTimer = null;
function toast(msg, type){
  var t = $('toast'); if(!t) return;
  t.textContent = msg;
  t.className = 'toast show' + (type === 'err' ? ' err' : '');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ t.className = 'toast'; }, 2600);
}
function openModal(html){
  $('modalRoot').innerHTML = '<div class="modal-backdrop"><div class="modal">' + html + '</div></div>';
  document.body.classList.add('no-scroll');
  var bk = document.querySelector('.modal-backdrop');
  if(bk){ bk.addEventListener('click', function(e){ if(e.target === bk) closeModal(); }); }
}
function closeModal(){ $('modalRoot').innerHTML = ''; document.body.classList.remove('no-scroll'); }

function save(){
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  catch(e){ toast('Gagal menyimpan. Storage penuh.', 'err'); }
}
function load(){
  var raw = null;
  try { raw = localStorage.getItem(STORAGE_KEY); } catch(e){ raw = null; }
  if(!raw) return;
  try {
    var parsed = JSON.parse(raw);
    var res = sanitizeState(parsed, false);
    if(res.ok) state = res.state;
  } catch(e){ console.warn('Data tidak dapat dibaca'); }
}
function sanitizeState(raw, strict){
  if(!raw || typeof raw !== 'object' || Array.isArray(raw)) return { ok:false, error:'Struktur tidak dikenali.' };
  var keys = ['accounts','categories','transactions','allocations'];
  for(var i=0;i<keys.length;i++){
    if(!Array.isArray(raw[keys[i]])) return { ok:false, error:'Bagian "'+keys[i]+'" tidak ditemukan.' };
  }
  var nowIso = new Date().toISOString();
  var accounts = [];
  for(var i=0;i<raw.accounts.length;i++){
    var a = raw.accounts[i];
    if(!a || typeof a !== 'object' || typeof a.name !== 'string' || !a.name.trim()){
      if(strict) return { ok:false, error:'Rekening tidak valid.' };
      continue;
    }
    accounts.push({ id:(typeof a.id==='string' && a.id) ? a.id : uid(), name:a.name.trim().slice(0,40), initialBalance:num(a.initialBalance), archived:!!a.archived, createdAt: typeof a.createdAt==='string' ? a.createdAt : nowIso });
  }
  var accIds = {}; accounts.forEach(function(a){ accIds[a.id]=true; });
  var categories = [];
  for(var i=0;i<raw.categories.length;i++){
    var c = raw.categories[i];
    if(!c || typeof c !== 'object' || typeof c.name !== 'string' || !c.name.trim()){
      if(strict) return { ok:false, error:'Kategori tidak valid.' };
      continue;
    }
    var pct = Number(c.percentage); if(!isFinite(pct)) pct = 0;
    pct = Math.min(100, Math.max(0, Math.round(pct*100)/100));
    categories.push({ id:(typeof c.id==='string' && c.id) ? c.id : uid(), name:c.name.trim().slice(0,40), percentage:pct, createdAt: typeof c.createdAt==='string' ? c.createdAt : nowIso });
  }
  var catIds = {}; categories.forEach(function(c){ catIds[c.id]=true; });
  var transactions = [];
  for(var i=0;i<raw.transactions.length;i++){
    var t = raw.transactions[i];
    if(!t || typeof t !== 'object' || ['income','expense','transfer'].indexOf(t.type) === -1){
      if(strict) return { ok:false, error:'Jenis transaksi tidak dikenal.' };
      continue;
    }
    var amount = num(t.amount);
    if(!(amount > 0)){
      if(strict) return { ok:false, error:'Nominal tidak valid.' };
      continue;
    }
    if(!accIds[t.accountId]){
      if(strict) return { ok:false, error:'Rekening tidak dikenal.' };
      continue;
    }
    if(t.type === 'transfer' && (!accIds[t.toAccountId] || t.toAccountId === t.accountId)){
      if(strict) return { ok:false, error:'Transfer tidak valid.' };
      continue;
    }
    transactions.push({ id:(typeof t.id==='string' && t.id) ? t.id : uid(), type:t.type, amount:amount, date: isISODate(t.date) ? t.date : todayISO(), accountId:t.accountId, toAccountId: t.type==='transfer' ? t.toAccountId : '', categoryId: (t.type==='expense' && catIds[t.categoryId]) ? t.categoryId : '', source: typeof t.source==='string' ? t.source.slice(0,60) : '', note: typeof t.note==='string' ? t.note.slice(0,200) : '', createdAt: typeof t.createdAt==='string' ? t.createdAt : nowIso });
  }
  var allocations = [];
  for(var i=0;i<raw.allocations.length;i++){
    var al = raw.allocations[i];
    if(!al || typeof al !== 'object'){
      if(strict) return { ok:false, error:'Pembagian tidak valid.' };
      continue;
    }
    var amt = num(al.amount);
    if(!(amt > 0) || !catIds[al.categoryId]){
      if(strict) return { ok:false, error:'Kategori pembagian tidak dikenal.' };
      continue;
    }
    allocations.push({ id:(typeof al.id==='string' && al.id) ? al.id : uid(), categoryId:al.categoryId, amount:amt, date: isISODate(al.date) ? al.date : todayISO(), txId: typeof al.txId==='string' ? al.txId : '', createdAt: typeof al.createdAt==='string' ? al.createdAt : nowIso });
  }
  return { ok:true, state:{ version:1, accounts:accounts, categories:categories, transactions:transactions, allocations:allocations } };
}