function accountById(id){ for(var i=0;i<state.accounts.length;i++) if(state.accounts[i].id===id) return state.accounts[i]; return null; }
function categoryById(id){ for(var i=0;i<state.categories.length;i++) if(state.categories[i].id===id) return state.categories[i]; return null; }
function accountName(id){ var a = accountById(id); return a ? a.name : '(rekening dihapus)'; }
function categoryName(id){ var c = categoryById(id); return c ? c.name : 'Tanpa kategori'; }
function accountBalance(id){
  var acc = accountById(id); if(!acc) return 0;
  var bal = num(acc.initialBalance);
  for(var i=0;i<state.transactions.length;i++){
    var t = state.transactions[i];
    if(t.type==='income' && t.accountId===id) bal += t.amount;
    else if(t.type==='expense' && t.accountId===id) bal -= t.amount;
    else if(t.type==='transfer'){
      if(t.accountId===id) bal -= t.amount;
      if(t.toAccountId===id) bal += t.amount;
    }
  }
  return bal;
}
function totalBalance(){ var s = 0; for(var i=0;i<state.accounts.length;i++) s += accountBalance(state.accounts[i].id); return s; }
function sumByMonth(type, mk){
  var s = 0;
  for(var i=0;i<state.transactions.length;i++){
    var t = state.transactions[i];
    if(t.type===type && monthKeyOf(t.date)===mk) s += t.amount;
  }
  return s;
}
function allocatedFor(catId){ var s=0; for(var i=0;i<state.allocations.length;i++) if(state.allocations[i].categoryId===catId) s += state.allocations[i].amount; return s; }
function allocatedForMonth(catId, mk){
  var s=0;
  for(var i=0;i<state.allocations.length;i++){
    var a = state.allocations[i];
    if(a.categoryId===catId && monthKeyOf(a.date)===mk) s += a.amount;
  }
  return s;
}
function spentFor(catId){ var s=0; for(var i=0;i<state.transactions.length;i++){ var t=state.transactions[i]; if(t.type==='expense' && t.categoryId===catId) s += t.amount; } return s; }
function totalPercent(){ var s=0; for(var i=0;i<state.categories.length;i++) s += Number(state.categories[i].percentage)||0; return Math.round(s*100)/100; }
function isBudgetReady(){ return state.categories.length>0 && Math.abs(totalPercent()-100)<0.005; }
function sortedTxDesc(list){
  return list.slice().sort(function(a,b){
    if(a.date !== b.date) return a.date < b.date ? 1 : -1;
    var ac = a.createdAt || '', bc = b.createdAt || '';
    if(ac !== bc) return ac < bc ? 1 : -1;
    return 0;
  });
}
function upsertTx(tx){
  for(var i=0;i<state.transactions.length;i++){
    if(state.transactions[i].id === tx.id){ state.transactions[i] = tx; return; }
  }
  state.transactions.push(tx);
}

function render(){
  var views = document.querySelectorAll('.view');
  for(var i=0;i<views.length;i++) views[i].classList.remove('active');
  var v = $('view-' + currentView); if(v) v.classList.add('active');
  var navs = document.querySelectorAll('.nav-btn');
  for(var i=0;i<navs.length;i++) navs[i].classList.toggle('active', navs[i].getAttribute('data-nav') === currentView);
  if(currentView==='dashboard') renderDashboard();
  else if(currentView==='accounts') renderAccounts();
  else if(currentView==='budget') renderBudget();
  else if(currentView==='transactions') renderTransactions();
  else if(currentView==='reports') renderReports();
}
function showView(name){ currentView = name; render(); window.scrollTo(0,0); }
function emptyState(title, text, btnLabel, action){
  return '<div class="card empty"><p class="empty-title">' + esc(title) + '</p><p class="empty-text">' + esc(text) + '</p>' +
    (btnLabel ? '<button class="btn btn-primary" data-action="' + action + '">' + esc(btnLabel) + '</button>' : '') + '</div>';
}
function txRow(t){
  var title='', sub='', amt='';
  if(t.type==='income'){ title = t.source || 'Pemasukan'; sub = accountName(t.accountId); amt = '+' + rupiah(t.amount); }
  else if(t.type==='expense'){ title = categoryName(t.categoryId); sub = accountName(t.accountId) + (t.note ? ' - ' + t.note : ''); amt = '-' + rupiah(t.amount); }
  else { title = 'Transfer'; sub = accountName(t.accountId) + ' -> ' + accountName(t.toAccountId); amt = rupiah(t.amount); }
  var iconCls = t.type==='income' ? 'pos' : (t.type==='expense' ? 'neg' : 'mut');
  return '<button class="tx-row" data-action="openTx" data-id="' + t.id + '">' +
    '<span class="tx-icon ' + iconCls + '">' + ICONS[t.type] + '</span>' +
    '<span class="tx-main"><span class="tx-title">' + esc(title) + '</span><span class="tx-sub">' + esc(sub) + '</span></span>' +
    '<span class="tx-right"><span class="tx-amt ' + (t.type==='income'?'pos':(t.type==='expense'?'neg':'')) + '">' + amt + '</span><span class="tx-date">' + fmtDateShort(t.date) + '</span></span>' +
    '</button>';
}

function renderDashboard(){
  var mk = monthKeyOf(todayISO());
  var income = sumByMonth('income', mk);
  var expense = sumByMonth('expense', mk);
  var total = totalBalance();
  var accs = state.accounts;
  var recent = sortedTxDesc(state.transactions).slice(0,5);
  var html = '';
  html += '<div class="hero"><p class="hero-label">Total Seluruh Saldo</p><p class="hero-amount">' + rupiah(total) + '</p><p class="hero-sub">' + (accs.length ? accs.length + ' rekening tercatat' : 'Belum ada rekening') + '</p></div>';
  html += '<div class="stat-row"><div class="stat"><span class="stat-label"><i class="dot dot-in"></i>Pemasukan bulan ini</span><span class="stat-value pos">' + rupiah(income) + '</span></div><div class="stat"><span class="stat-label"><i class="dot dot-out"></i>Pengeluaran bulan ini</span><span class="stat-value neg">' + rupiah(expense) + '</span></div></div>';
  html += '<div class="section"><div class="section-head"><h2>Saldo Rekening</h2><button class="link-btn" data-nav-link="accounts">Lihat semua</button></div>';
  if(!accs.length){
    html += emptyState('Belum ada rekening', 'Buat rekening virtual pertama Anda untuk mulai mencatat keuangan.', 'Tambah Rekening', 'addAccount');
  } else {
    html += '<div class="card">';
    accs.forEach(function(a){
      var bal = accountBalance(a.id);
      html += '<div class="acc-line"><span class="acc-line-name">' + esc(a.name) + (a.archived ? '<em class="tag">arsip</em>' : '') + '</span><span class="acc-line-bal ' + (bal<0?'neg':'') + '">' + rupiah(bal) + '</span></div>';
    });
    html += '</div>';
  }
  html += '</div>';
  html += '<div class="section"><div class="section-head"><h2>Pembagian Anggaran</h2><button class="link-btn" data-nav-link="budget">Kelola</button></div>';
  if(!state.categories.length){
    html += emptyState('Belum ada kategori anggaran', 'Tentukan kategori dan persentasenya agar pemasukan dapat dibagi otomatis.', 'Atur Anggaran', 'addCategory');
  } else {
    html += '<div class="card">';
    state.categories.forEach(function(c){
      var alloc = allocatedFor(c.id);
      var spent = spentFor(c.id);
      var pct = alloc > 0 ? Math.min(100, Math.round(spent/alloc*100)) : 0;
      html += '<div class="bud-row"><div class="bud-top"><span>' + esc(c.name) + '</span><span class="bud-pct">' + fmtPct(c.percentage) + '</span></div><div class="progress"><div style="width:' + pct + '%"></div></div><div class="bud-bottom"><span>Terpakai ' + rupiah(spent) + '</span><span>Sisa ' + rupiah(alloc-spent) + '</span></div></div>';
    });
    html += '</div>';
  }
  html += '</div>';
  html += '<div class="section"><div class="section-head"><h2>Transaksi Terbaru</h2><button class="link-btn" data-nav-link="transactions">Lihat semua</button></div>';
  if(!recent.length){
    html += emptyState('Belum ada transaksi', 'Mulai catat pemasukan, pengeluaran, atau transfer antar rekening.', 'Catat Transaksi', 'gotoTransactions');
  } else {
    html += '<div class="card">' + recent.map(txRow).join('') + '</div>';
  }
  html += '</div>';
  $('view-dashboard').innerHTML = html;
}

function renderAccounts(){
  var active = state.accounts.filter(function(a){ return !a.archived; });
  var archived = state.accounts.filter(function(a){ return a.archived; });
  var html = '<div class="section-head"><h2>Rekening Saya</h2></div><button class="btn btn-primary btn-block" data-action="addAccount" style="margin-bottom:14px">+ Tambah Rekening</button>';
  if(!state.accounts.length){
    html += emptyState('Belum ada rekening', 'Rekening di sini hanya catatan internal, bukan rekening bank sungguhan.', null, null);
  } else {
    if(active.length) html += active.map(accCard).join('');
    if(archived.length) html += '<p class="date-head">Diarsipkan</p>' + archived.map(accCard).join('');
  }
  $('view-accounts').innerHTML = html;
}
function accCard(a){
  var bal = accountBalance(a.id);
  return '<div class="card acc-card"><div class="row-between"><div style="min-width:0"><p class="acc-name">' + esc(a.name) + '</p><p class="acc-sub">Saldo awal ' + rupiah(a.initialBalance) + '</p></div><p class="acc-balance ' + (bal<0?'neg':'') + '">' + rupiah(bal) + '</p></div><div class="acc-actions"><button class="btn btn-sm" data-action="accHistory" data-id="' + a.id + '">Riwayat</button><button class="btn btn-sm" data-action="editAccount" data-id="' + a.id + '">Edit</button><button class="btn btn-sm btn-ghost" data-action="toggleArchive" data-id="' + a.id + '">' + (a.archived?'Aktifkan':'Arsipkan') + '</button></div></div>';
}
function openAccountForm(acc){
  var isEdit = !!acc;
  openModal('<h3>' + (isEdit?'Edit Rekening':'Rekening Baru') + '</h3><p class="modal-sub">Catatan internal untuk memisahkan uang Anda.</p><form id="accForm"><div class="field"><label>Nama rekening</label><input name="name" type="text" maxlength="40" placeholder="Contoh: Gaji Koperasi" value="' + (isEdit?esc(acc.name):'') + '" required /></div><div class="field"><label>Saldo awal</label><input name="initialBalance" type="text" inputmode="numeric" placeholder="0" value="' + (isEdit && acc.initialBalance ? acc.initialBalance.toLocaleString('id-ID') : '') + '" /></div><div class="modal-actions"><button type="button" class="btn btn-ghost" data-action="closeModal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div></form>');
  bindAmountInput(document.querySelector('#accForm [name="initialBalance"]'));
  $('accForm').addEventListener('submit', function(e){
    e.preventDefault();
    var fd = new FormData(e.target);
    var name = String(fd.get('name')||'').trim();
    if(!name){ toast('Nama rekening wajib diisi', 'err'); return; }
    var initialBalance = parseAmountInput(fd.get('initialBalance'));
    if(isEdit){ acc.name = name.slice(0,40); acc.initialBalance = initialBalance; }
    else { state.accounts.push({ id:uid(), name:name.slice(0,40), initialBalance:initialBalance, archived:false, createdAt:new Date().toISOString() }); }
    save(); closeModal(); render();
    toast(isEdit ? 'Rekening diperbarui' : 'Rekening ditambahkan');
  });
}
function toggleArchive(id){
  var a = accountById(id); if(!a) return;
  if(!a.archived){
    if(!confirm('Arsipkan rekening "' + a.name + '"? Riwayat transaksi tetap tersimpan.')) return;
    a.archived = true; toast('Rekening diarsipkan');
  } else { a.archived = false; toast('Rekening diaktifkan kembali'); }
  save(); render();
}

function renderBudget(){
  var total = totalPercent();
  var ok = state.categories.length>0 && Math.abs(total-100)<0.005;
  var width = Math.min(100, Math.max(0, total));
  var html = '<div class="card"><div class="row-between"><span style="font-size:13px;font-weight:700">Total Persentase</span><strong style="font-size:17px" class="' + (ok?'pos':(total>100?'neg':'')) + '">' + fmtPct(total) + '</strong></div><div class="progress"><div style="width:' + width + '%"></div></div><p class="hint ' + (ok?'':'warn') + '">' + (ok?'Persentase sudah tepat 100%. Pembagian otomatis tersedia saat mencatat pemasukan.':(state.categories.length===0?'Belum ada kategori. Tambahkan kategori dan atur persentasenya.':'Total persentase harus tepat 100% agar pembagian anggaran dapat digunakan.')) + '</p></div>';
  html += '<button class="btn btn-primary btn-block" data-action="addCategory" style="margin-bottom:14px">+ Tambah Kategori</button>';
  if(!state.categories.length){
    html += emptyState('Belum ada kategori anggaran', 'Contoh: Kebutuhan harian, Keluarga, Tabungan laptop, Modal bisnis, Dana darurat.', null, null);
  } else {
    html += state.categories.map(function(c){
      var alloc = allocatedFor(c.id);
      var spent = spentFor(c.id);
      var sisa = alloc - spent;
      var pct = alloc>0 ? Math.min(100, Math.round(spent/alloc*100)) : 0;
      return '<div class="card"><div class="row-between"><div style="min-width:0"><p style="margin:0;font-size:14.5px;font-weight:700">' + esc(c.name) + '</p><p style="margin:2px 0 0;font-size:11.5px;color:var(--muted)">Persentase ' + fmtPct(c.percentage) + '</p></div><div style="display:flex;gap:6px;flex:none"><button class="btn btn-sm" data-action="editCategory" data-id="' + c.id + '">Edit</button><button class="btn btn-sm btn-ghost" data-action="deleteCategory" data-id="' + c.id + '">Hapus</button></div></div><div class="progress"><div style="width:' + pct + '%"></div></div><div class="bud-bottom"><span>Dialokasikan ' + rupiah(alloc) + '</span><span>Terpakai ' + rupiah(spent) + '</span><span class="' + (sisa<0?'neg':'') + '">Sisa ' + rupiah(sisa) + '</span></div></div>';
    }).join('');
    if(ok) html += '<button class="btn btn-sage btn-block" data-action="manualAlloc" style="margin-top:4px">Bagi Dana ke Anggaran</button>';
  }
  $('view-budget').innerHTML = html;
}
function openCategoryForm(cat){
  var isEdit = !!cat;
  var others = 0;
  state.categories.forEach(function(c){ if(!isEdit || c.id !== cat.id) others += Number(c.percentage)||0; });
  var sisa = Math.max(0, 100 - others);
  openModal('<h3>' + (isEdit?'Edit Kategori':'Kategori Anggaran Baru') + '</h3><p class="modal-sub">Sisa persentase tersedia: <strong>' + fmtPct(sisa) + '</strong></p><form id="catForm"><div class="field"><label>Nama kategori</label><input name="name" type="text" maxlength="40" placeholder="Contoh: Tabungan laptop" value="' + (isEdit?esc(cat.name):'') + '" required /></div><div class="field"><label>Persentase (%)</label><input name="percentage" type="text" inputmode="decimal" placeholder="0" value="' + (isEdit?String(cat.percentage).replace('.',','):'') + '" /></div><div class="modal-actions"><button type="button" class="btn btn-ghost" data-action="closeModal">Batal</button><button type="submit" class="btn btn-primary">Simpan</button></div></form>');
  $('catForm').addEventListener('submit', function(e){
    e.preventDefault();
    var fd = new FormData(e.target);
    var name = String(fd.get('name')||'').trim();
    if(!name){ toast('Nama kategori wajib diisi', 'err'); return; }
    var rawPct = String(fd.get('percentage')||'').replace(',', '.').trim();
    var pct = Math.round((Number(rawPct)||0)*100)/100;
    if(pct < 0 || pct > 100){ toast('Persentase harus antara 0 dan 100', 'err'); return; }
    if(others + pct > 100.001){ toast('Total melebihi 100%. Sisa: ' + fmtPct(sisa), 'err'); return; }
    if(isEdit){ cat.name = name.slice(0,40); cat.percentage = pct; }
    else { state.categories.push({ id:uid(), name:name.slice(0,40), percentage:pct, createdAt:new Date().toISOString() }); }
    save(); closeModal(); render();
    toast(isEdit ? 'Kategori diperbarui' : 'Kategori ditambahkan');
  });
}
function deleteCategory(id){
  var c = categoryById(id); if(!c) return;
  if(!confirm('Hapus kategori "' + c.name + '"? Pengeluaran dengan kategori ini akan menjadi "Tanpa kategori".')) return;
  state.categories = state.categories.filter(function(x){ return x.id !== id; });
  state.allocations = state.allocations.filter(function(a){ return a.categoryId !== id; });
  state.transactions.forEach(function(t){ if(t.categoryId === id) t.categoryId = ''; });
  save(); render(); toast('Kategori dihapus');
}
function openManualAlloc(){
  if(!isBudgetReady()){ toast('Total persentase harus 100% terlebih dahulu', 'err'); return; }
  openModal('<h3>Bagi Dana ke Anggaran</h3><p class="modal-sub">Masukkan nominal yang ingin dibagi sesuai persentase kategori.</p><form id="manualAllocForm"><div class="field"><label>Nominal</label><input name="amount" type="text" inputmode="numeric" placeholder="0" /></div><div class="modal-actions"><button type="button" class="btn btn-ghost" data-action="closeModal">Batal</button><button type="submit" class="btn btn-primary">Lanjut</button></div></form>');
  bindAmountInput(document.querySelector('#manualAllocForm [name="amount"]'));
  $('manualAllocForm').addEventListener('submit', function(e){
    e.preventDefault();
    var amt = parseAmountInput(new FormData(e.target).get('amount'));
    if(!(amt > 0)){ toast('Nominal harus lebih dari 0', 'err'); return; }
    openAllocationSheet(amt, todayISO(), null);
  });
}
function openAllocationSheet(amount, date, txToSave){
  if(!state.categories.length){ toast('Belum ada kategori anggaran', 'err'); return; }
  allocContext = { amount: num(amount), date: date || todayISO(), tx: txToSave || null };
  var base = allocContext.amount;
  var rows = state.categories.map(function(c){
    var pct = Number(c.percentage)||0;
    var amt = Math.round(base * pct / 100);
    return '<div class="alloc-row"><div class="alloc-info"><span>' + esc(c.name) + '</span><small>' + fmtPct(pct) + '</small></div><input class="alloc-input" data-cat="' + c.id + '" type="text" inputmode="numeric" value="' + (amt ? amt.toLocaleString('id-ID') : '') + '" placeholder="0" /></div>';
  }).join('');
  openModal('<h3>Pembagian Anggaran</h3><p class="modal-sub">Nominal: <strong>' + rupiah(base) + '</strong>. Anda dapat mengubah setiap nominal sebelum menyimpan.</p><div class="alloc-list">' + rows + '</div><div class="alloc-total"><span>Total pembagian</span><strong id="allocTotal">Rp0</strong></div><p class="hint" id="allocHint"></p><div class="modal-actions col"><button class="btn btn-sage" data-action="confirmAlloc">Konfirmasi Pembagian</button><button class="btn btn-ghost" data-action="skipAlloc">' + (allocContext.tx?'Simpan Tanpa Membagi':'Batal') + '</button></div>');
  var ins = document.querySelectorAll('.alloc-input');
  for(var i=0;i<ins.length;i++){
    ins[i].addEventListener('input', function(e){
      var d = e.target.value.replace(/\D/g, '').slice(0,15);
      e.target.value = d ? Number(d).toLocaleString('id-ID') : '';
      updateAllocTotal();
    });
  }
  updateAllocTotal();
}
function updateAllocTotal(){
  var total = 0;
  var ins = document.querySelectorAll('.alloc-input');
  for(var i=0;i<ins.length;i++) total += parseAmountInput(ins[i].value);
  var elTotal = $('allocTotal'); if(elTotal) elTotal.textContent = rupiah(total);
  var hint = $('allocHint'); if(!hint || !allocContext) return;
  var diff = allocContext.amount - total;
  if(diff === 0){ hint.className = 'hint'; hint.textContent = 'Total pembagian sama dengan nominal yang dibagi.'; }
  else if(diff > 0){ hint.className = 'hint'; hint.textContent = 'Belum dibagikan: ' + rupiah(diff); }
  else { hint.className = 'hint warn'; hint.textContent = 'Total melebihi nominal sebesar ' + rupiah(-diff) + '.'; }
}
function confirmAllocation(){
  if(!allocContext) return;
  var picks = [];
  var ins = document.querySelectorAll('.alloc-input');
  for(var i=0;i<ins.length;i++){
    var amt = parseAmountInput(ins[i].value);
    if(amt > 0) picks.push({ categoryId: ins[i].getAttribute('data-cat'), amount: amt });
  }
  if(!picks.length){ toast('Isi minimal satu nominal pembagian', 'err'); return; }
  var ctx = allocContext;
  var now = new Date().toISOString();
  if(ctx.tx) upsertTx(ctx.tx);
  for(var i=0;i<picks.length;i++){
    state.allocations.push({ id:uid(), categoryId:picks[i].categoryId, amount:picks[i].amount, date:ctx.date, txId:ctx.tx ? ctx.tx.id : '', createdAt:now });
  }
  allocContext = null;
  save(); closeModal(); render();
  toast(ctx.tx ? 'Pemasukan & pembagian disimpan' : 'Pembagian disimpan');
}
function skipAllocation(){
  var ctx = allocContext;
  allocContext = null;
  if(ctx && ctx.tx){ upsertTx(ctx.tx); save(); closeModal(); render(); toast('Pemasukan disimpan tanpa pembagian'); }
  else closeModal();
}